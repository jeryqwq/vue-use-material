<template>
  <div>
  <div class="test">
  这是个渲染的Vue3.vue组件, 颜色绿
  <h1>{{a}} ref: {{b}}</h1>
  </div>
  </div>
</template>
<script setup>
  import { reative , ref} from 'vue'
  const a = 123
  const b = ref(1)
  console.warn('vue3.vue setup running...')
</script>
<style scoped lang="scss">
  div.test{
  color: green
  }
</style>
   