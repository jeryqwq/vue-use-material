<template>
    <div style="text-align: center">
      <img src="./assets/vue.png" style="width: 100px"/>
      <h2>HELLO Vue in VIS-CODE-EDITOR</h2>
      <Main />
    </div>
  </template>
  <script>
    import './a/b.js'
    import Main from './vue3.vue'
    console.error('exec index.vue script code')
    console.warn(echarts)
    export default {
      components: { Main },
      created() {
        console.log('index.vue created !!!!')
      },
      mounted(){
        console.log('index.vue mounted !!!!')
      }
    }
  </script>
  <style scoped lang="scss">
    img{
      margin: 20px
    }
    h2{
      color: red
    }
  </style>
   